"""
DIY Spacemouse - Blender addon

Reads live USB HID gamepad reports directly from the Pico (same approach
we used for the Fusion attempt - direct HID via the "hid" package, no
vendor driver, no OS joystick-mapping layer) and drives the active 3D
viewport camera via a modal operator.

Why HID directly instead of Blender's NDOF event system:
Blender's native 6DoF/"NDOF" input path (NDOF_MOTION events) is wired to
3Dconnexion's own device detection (spacenavd on Linux, their driver on
Mac/Windows) - a generic-VID DIY device will not trigger those events.
Reading the raw HID report ourselves sidesteps that entirely; the device
just needs to be visible as a generic HID gamepad, which it already is
(confirmed working on hardwaretester.com).

Setup required before this will import correctly - run once in a
terminal, pointing pip at Blender's own bundled Python:

  macOS (Blender.app default install):
    /Applications/Blender.app/Contents/Resources/<version>/python/bin/python3.* \
      -m ensurepip
    /Applications/Blender.app/Contents/Resources/<version>/python/bin/python3.* \
      -m pip install hid --break-system-packages

  Also needed - the native hidapi library (same as the Fusion attempt):
    brew install hidapi
    # Apple Silicon: if Blender can't find it, launch Blender from a
    # terminal with:
    export DYLD_LIBRARY_PATH=/opt/homebrew/lib:$DYLD_LIBRARY_PATH

  Windows: pip install hid (hidapi.dll ships inside the "hid" wheel on
  Windows, no separate native install needed).

  Linux: sudo apt install libhidapi-hidraw0  (or libhidapi-libusb0),
  then pip install hid same as above.

Then: Edit > Preferences > Add-ons > Install..., pick this file's
containing folder zipped up (or point Blender at this .py directly if
installing as a single-file legacy addon), enable "DIY Spacemouse".
Open the 3D Viewport sidebar (N-panel) > "Spacemouse" tab > Start.
"""

bl_info = {
    "name": "DIY Spacemouse",
    "author": "Team Decagon",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Spacemouse",
    "description": "Drive the 3D viewport from a DIY HID 6DoF controller",
    "category": "3D View",
}

import bpy
import ctypes
import glob
import math
import os
import platform
import threading
import time

# --- Redirect the "hid" package's bare-filename library lookup to a full
# known path, before importing it. ---
# The "hid" package's __init__.py does ctypes.cdll.LoadLibrary('libhidapi.dylib')
# by bare filename only, relying on the OS's default dynamic-linker search
# path. Blender's .app bundle runs as its own sandboxed process and does
# not search /opt/homebrew/lib by default (confirmed: DYLD_LIBRARY_PATH
# does not reach it however Blender is launched, and even pre-loading the
# library by full path first does NOT make a later bare-name dlopen() call
# succeed - macOS's dyld re-searches by name regardless of what's already
# loaded under a different path string).
# Fix: monkeypatch ctypes.cdll.LoadLibrary itself so that when "hid" asks
# for the exact bare name "libhidapi.dylib" (or the Linux/Windows
# equivalents), it transparently gets the full resolved path instead.
_HIDAPI_CANDIDATES = []
if platform.system() == "Darwin":
    _HIDAPI_CANDIDATES += [
        "/opt/homebrew/lib/libhidapi.dylib",       # Homebrew, Apple Silicon
        "/usr/local/lib/libhidapi.dylib",           # Homebrew, Intel / manual symlink
    ]
    _HIDAPI_CANDIDATES += glob.glob("/opt/homebrew/Cellar/hidapi/*/lib/libhidapi.dylib")
    _HIDAPI_CANDIDATES += glob.glob("/usr/local/Cellar/hidapi/*/lib/libhidapi.dylib")
elif platform.system() == "Linux":
    _HIDAPI_CANDIDATES += [
        "/usr/lib/x86_64-linux-gnu/libhidapi-hidraw.so.0",
        "/usr/lib/libhidapi-hidraw.so.0",
        "/usr/local/lib/libhidapi-hidraw.so",
    ]
# Windows: the "hid" wheel ships hidapi.dll bundled - no redirect needed.

_hidapi_resolved_path = None
for _path in _HIDAPI_CANDIDATES:
    if os.path.exists(_path):
        _hidapi_resolved_path = _path
        break

_hidapi_preload_error = None
if _hidapi_resolved_path:
    _orig_load_library = ctypes.cdll.LoadLibrary

    def _patched_load_library(name, *args, **kwargs):
        # Redirect only hidapi's own bare-name variants; anything else
        # (other ctypes usage elsewhere in Blender/addons) passes through
        # untouched.
        bare_names = (
            "libhidapi.dylib", "libhidapi-hidraw.so", "libhidapi-hidraw.so.0",
            "libhidapi-libusb.so", "libhidapi-libusb.so.0",
            "libhidapi-iohidmanager.so", "libhidapi-iohidmanager.so.0",
        )
        if name in bare_names:
            return _orig_load_library(_hidapi_resolved_path, *args, **kwargs)
        return _orig_load_library(name, *args, **kwargs)

    ctypes.cdll.LoadLibrary = _patched_load_library
elif platform.system() != "Windows":
    _hidapi_preload_error = "libhidapi not found in any of: " + ", ".join(_HIDAPI_CANDIDATES)

try:
    import hid
except ImportError as e:
    hid = None
    _hid_import_error = str(e)
    if _hidapi_preload_error:
        _hid_import_error += "\n(native lib search also failed: {})".format(_hidapi_preload_error)
else:
    _hid_import_error = None
finally:
    # Restore the original loader so we don't leave a global monkeypatch
    # affecting unrelated ctypes.cdll.LoadLibrary calls elsewhere.
    if _hidapi_resolved_path:
        ctypes.cdll.LoadLibrary = _orig_load_library

# Must match what the firmware sets via TinyUSBDevice.setID(vid, pid).
# Firmware currently uses the shared pid.codes hobby VID, not a real
# vendor's registered identity.
DEVICE_VID = 0x1209
DEVICE_PID = 0x0001

# --- Tuning: scales raw int8 axis values (-127..127) down to something
# sane for per-tick camera movement. Start conservative, retune by feel
# the same way the firmware gains were tuned. ---
TRANSLATE_SCALE = 0.01
ROTATE_SCALE = 0.01
DEADZONE = 4  # raw int8 units - ignore tiny noise around center

# hid_gamepad_report_t field order (TinyUSB TUD_HID_REPORT_DESC_GAMEPAD):
#   x, y, z, rz, rx, ry  (int8 each), hat (uint8), buttons (uint32)
# No report-ID byte in the struct itself, but hidapi on some platforms
# prepends a 0x00 report-ID byte for unnumbered reports - handled below
# by trying both offsets.
AXIS_ORDER = ("x", "y", "z", "rz", "rx", "ry")


class SpacemouseState:
    """Shared state between the background HID-reader thread and the
    modal operator's per-tick camera update. Plain dict + lock - no
    Blender API calls from the reader thread, since bpy is not
    thread-safe to call off the main thread."""

    def __init__(self):
        self.lock = threading.Lock()
        self.axes = {k: 0.0 for k in AXIS_ORDER}
        self.connected = False
        self.stop_flag = threading.Event()
        self.thread = None
        self.device = None
        self.error = None

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stop_flag.clear()
        self.error = None
        self.thread = threading.Thread(target=self._reader_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_flag.set()
        if self.thread:
            self.thread.join(timeout=1.0)
        if self.device:
            try:
                self.device.close()
            except Exception:
                pass
            self.device = None
        with self.lock:
            self.connected = False

    def _reader_loop(self):
        if hid is None:
            self.error = _hid_import_error or "The 'hid' package failed to import - see addon setup notes."
            return

        try:
            self.device = hid.Device(DEVICE_VID, DEVICE_PID)
        except Exception as e:
            self.error = "Could not open device (VID 0x{:04x} / PID 0x{:04x}): {}".format(
                DEVICE_VID, DEVICE_PID, e
            )
            return

        with self.lock:
            self.connected = True

        while not self.stop_flag.is_set():
            try:
                report = self.device.read(64, timeout=50)
            except Exception as e:
                self.error = "Read error: {}".format(e)
                break

            if report:
                parsed = self._parse_report(report)
                if parsed:
                    with self.lock:
                        self.axes.update(parsed)

        with self.lock:
            self.connected = False

    def _parse_report(self, report):
        # hid_gamepad_report_t is 11 bytes: x,y,z,rz,rx,ry (int8 each),
        # hat (uint8), buttons (uint32 LE). Some platforms/backends
        # prepend a report-ID byte (0x00) for unnumbered reports, so
        # try offset 0 first, then offset 1 if the byte count fits.
        def read_at(offset):
            if len(report) < offset + 6:
                return None
            vals = {}
            for i, name in enumerate(AXIS_ORDER):
                b = report[offset + i]
                # int8 from an unsigned byte value
                vals[name] = b - 256 if b > 127 else b
            return vals

        # Heuristic: real axis data should mostly sit near 0 at rest and
        # never exceed the int8 range by construction, so either offset
        # "works" numerically - prefer offset 0 (no report-ID prefix),
        # matching our unnumbered HID_REPORT_DESC_GAMEPAD descriptor.
        parsed = read_at(0)
        if parsed is None:
            parsed = read_at(1)
        return parsed

    def get_axes(self):
        with self.lock:
            return dict(self.axes), self.connected, self.error


_state = SpacemouseState()


def _apply_deadzone(v):
    if abs(v) < DEADZONE:
        return 0.0
    return (v - DEADZONE) if v > 0 else (v + DEADZONE)


class SPACEMOUSE_OT_run(bpy.types.Operator):
    """Modal operator: polls the HID reader thread's latest axes each
    timer tick and nudges the active 3D viewport's camera accordingly.
    Runs until Stop is pressed or the viewport area is closed."""

    bl_idname = "spacemouse.run"
    bl_label = "Start Spacemouse"

    _timer = None

    def modal(self, context, event):
        if context.scene.spacemouse_should_stop:
            self.cancel(context)
            return {"CANCELLED"}

        if event.type == "TIMER":
            axes, connected, error = _state.get_axes()
            context.scene.spacemouse_connected = connected
            context.scene.spacemouse_error = error or ""

            if connected:
                self._drive_view(context, axes)

        return {"PASS_THROUGH"}

    def _drive_view(self, context, axes):
        rv3d = None
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                rv3d = area.spaces[0].region_3d
                break
        if rv3d is None:
            return

        tx = _apply_deadzone(axes.get("x", 0.0)) * TRANSLATE_SCALE
        ty = _apply_deadzone(axes.get("y", 0.0)) * TRANSLATE_SCALE
        tz = _apply_deadzone(axes.get("z", 0.0)) * TRANSLATE_SCALE
        rx = _apply_deadzone(axes.get("rx", 0.0)) * ROTATE_SCALE
        ry = _apply_deadzone(axes.get("ry", 0.0)) * ROTATE_SCALE
        rz = _apply_deadzone(axes.get("rz", 0.0)) * ROTATE_SCALE

        if tx or ty or tz:
            # Pan: move the view's look-at point in its own local
            # right/up/forward basis so panning feels camera-relative.
            right = rv3d.view_rotation @ bpy_vector(1, 0, 0)
            up = rv3d.view_rotation @ bpy_vector(0, 1, 0)
            fwd = rv3d.view_rotation @ bpy_vector(0, 0, -1)
            rv3d.view_location += right * tx + up * tz + fwd * (-ty)

        if rx or ry or rz:
            # Orbit: yaw around world Z from rz, pitch from rx, using
            # Blender's own view_rotation quaternion so it composes
            # correctly with whatever orientation the view is already in.
            yaw = axis_angle_quat(bpy_vector(0, 0, 1), rz * -1)
            pitch = axis_angle_quat(bpy_vector(1, 0, 0), rx)
            rv3d.view_rotation = yaw @ rv3d.view_rotation @ pitch

        if rv3d.view_perspective == "CAMERA":
            rv3d.view_perspective = "PERSP"

        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()

    def execute(self, context):
        context.scene.spacemouse_should_stop = False
        _state.start()
        wm = context.window_manager
        self._timer = wm.event_timer_add(1.0 / 60.0, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        _state.stop()
        context.scene.spacemouse_connected = False


class SPACEMOUSE_OT_stop(bpy.types.Operator):
    bl_idname = "spacemouse.stop"
    bl_label = "Stop Spacemouse"

    def execute(self, context):
        context.scene.spacemouse_should_stop = True
        return {"FINISHED"}


class SPACEMOUSE_PT_panel(bpy.types.Panel):
    bl_idname = "SPACEMOUSE_PT_panel"
    bl_label = "Spacemouse"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Spacemouse"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        if hid is None:
            layout.label(text="'hid' import failed:", icon="ERROR")
            box = layout.box()
            msg = _hid_import_error or "unknown error"
            for line in msg.split("\n"):
                # wrap long lines so they don't get clipped in the narrow sidebar
                while len(line) > 40:
                    box.label(text=line[:40])
                    line = line[40:]
                box.label(text=line)
            return

        row = layout.row()
        if scene.spacemouse_connected:
            row.label(text="Connected", icon="CHECKMARK")
        else:
            row.label(text="Not connected", icon="RADIOBUT_OFF")

        if scene.spacemouse_error:
            box = layout.box()
            box.label(text="Error:", icon="ERROR")
            box.label(text=scene.spacemouse_error)

        layout.separator()
        if not scene.spacemouse_should_stop and _state.thread and _state.thread.is_alive():
            layout.operator("spacemouse.stop", icon="PAUSE")
        else:
            layout.operator("spacemouse.run", icon="PLAY")


def bpy_vector(x, y, z):
    import mathutils
    return mathutils.Vector((x, y, z))


def axis_angle_quat(axis, angle):
    import mathutils
    return mathutils.Quaternion(axis, angle)


classes = (
    SPACEMOUSE_OT_run,
    SPACEMOUSE_OT_stop,
    SPACEMOUSE_PT_panel,
)


def register():
    bpy.types.Scene.spacemouse_connected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.spacemouse_error = bpy.props.StringProperty(default="")
    bpy.types.Scene.spacemouse_should_stop = bpy.props.BoolProperty(default=False)
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    _state.stop()
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.spacemouse_connected
    del bpy.types.Scene.spacemouse_error
    del bpy.types.Scene.spacemouse_should_stop


if __name__ == "__main__":
    register()
